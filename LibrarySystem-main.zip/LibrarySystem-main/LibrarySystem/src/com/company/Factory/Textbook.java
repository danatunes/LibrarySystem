package com.company.Factory;

public class Textbook extends  Book{
    public Textbook(String title, String author) {
        super(title, author);
    }
}
