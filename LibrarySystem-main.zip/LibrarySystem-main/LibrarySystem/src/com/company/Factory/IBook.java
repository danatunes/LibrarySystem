package com.company.Factory;

import java.util.List;

public interface IBook {
    void displayBook();

}
