package com.company.Factory;

public class Magazine extends Book{
    public Magazine(String title, String author) {
        super(title, author);
    }
}
